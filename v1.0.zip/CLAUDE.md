# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

RAG-based AI Tutor for ULBS university students. Students upload textbooks/notes; the system processes them into a vector database and answers study queries with context-grounded responses, supporting output modes like quizzes, info cards, and explanations.

**Stack:** FastAPI + Qdrant + PostgreSQL + MinIO + Ollama (embeddings) + OpenAI (LLM) backend; Next.js 16 + React 19 + TypeScript + Tailwind CSS v4 frontend.

**Repo layout:** `backend/` and `frontend/` are each their own separate git repos. The root directory (`ULBS-coach/`) is **not** a git repo — run git commands from inside `backend/` or `frontend/`.

## Backend Dev Setup

### 1. Python environment (run from `backend/`)
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 2. Environment variables
```bash
cp .env.example .env
# Fill in values — see .env.example inline comments for each variable
```

### 3. Infrastructure (Qdrant + MinIO + PostgreSQL via Docker)
```bash
cd backend
docker compose up -d
```
Individual services: `docker compose up -d qdrant`, `docker compose up -d minio`, `docker compose up -d postgres`.

### 4. Embedding model (Ollama, run natively — not in Docker)
```bash
# Install Ollama from https://ollama.com/, then:
ollama create my-project-embed -f backend/Modelfile
```
Modelfile pulls `hf.co/Qwen/Qwen3-Embedding-4B-GGUF:Q8_0`. Set `EMBEDDING_CLIENT_TYPE=ollama` and `OLLAMA_EMBED_MODEL=my-project-embed` in `.env`.

### 5. Run the API
```bash
cd backend
fastapi dev app/main.py     # development (auto-reload)
# or
uvicorn app.main:app --reload
```
Swagger UI: `http://localhost:8000/docs`

**First startup** downloads the BGE-M3 sparse encoder (~570 MB) and cross-encoder reranker models if not cached at `~/.cache/huggingface`.

### 6. Run integration tests

Tests are standalone scripts, not pytest. Run from `backend/` so `.env` is found:
```bash
cd backend
.venv/bin/python test/qdrant/test_qdrant_client.py
.venv/bin/python test/embedding/test_embedding.py
.venv/bin/python test/minio/test_minio_client.py
```

### 7. Seed the database

`scripts/seed.py` populates all tables with fixed-UUID data (run from `backend/` with venv active):
```bash
python -m scripts.seed                  # mock mode — idempotent, Postgres only (no files/vectors)
python -m scripts.seed --reset          # truncate all tables, then seed
python -m scripts.seed --embed          # also run real PDFs from scripts/seed_materials/ through the full ingestion pipeline (needs Ollama + Qdrant + MinIO)
python -m scripts.seed --dry-run        # preview without touching the DB
```
Mock mode is idempotent; `--embed` is **not** (each run creates fresh Material UUIDs — use `--reset --embed` to re-embed cleanly). Only 2 randomly chosen professor courses receive materials. See `scripts/README.md` for details.

## Frontend Dev Setup

```bash
cd frontend
npm install
npm run dev        # http://localhost:3000
npm run build      # production build
npm run lint       # ESLint
npm run format     # Prettier (writes in place)
```

The frontend expects `NEXT_PUBLIC_API_URL` in `frontend/.env` (defaults to `http://127.0.0.1:8000`). The API prefix is hardcoded as `/api/v1` in `lib/config.ts`.

### Frontend architecture

- `app/(app)/` — authenticated route group: `chat/[id]/`, `courses/[id]/`
- `app/(auth)/` — unauthenticated route group: `login/`, `signup/`
- `components/` — domain-split UI components: `auth/` (LoginForm, SignUpForm), `chat/` (Chat, MessageInput, MessageList, Sidebar), `courses/` (CourseCard, AddCourseModal, EditCourseModal), `landing/` (Hero, Navbar, ThemeToggle)
- `lib/api.ts` — all backend API calls; SSE streams decoded manually with `ReadableStream` (no SSE library)
- `lib/types.ts` — TypeScript types mirroring backend Pydantic schemas
- `lib/chat-context.tsx` — React context for conversation state
- `lib/config.ts` — `NEXT_PUBLIC_API_URL` + `/api/v1` prefix

`lib/api.ts` calls `POST /sessions/{id}/regenerate`, which is implemented in the backend (`sessions.py` → `ChatService.regenerate_stream`).

## Backend Architecture

### Request flow (RAG pipeline)
```
Router → ChatService → EmbeddingClient  → QdrantClient (dense search)
                    ↘ BGEM3SparseEncoder → QdrantClient (sparse search)
                    → rrf_fuse()        (client-side RRF fusion, fusion.py)
                    → CrossEncoderReranker (rerank top candidates)
                    → LLM → SSE stream
```

1. **API layer** (`app/api/routers/`) — thin HTTP handlers, no business logic. Router prefix convention: `/api/v1/<domain>` (e.g. `/api/v1/sessions`, `/api/v1/courses`).
2. **Service layer** (`app/services/`) — orchestrates the full RAG pipeline
3. **RAG engine** (`app/rag_engine/`) — pure domain logic: `query_rewrite.py` (query condensation), `fusion.py` (RRF)
4. **Data access** (`app/data_access/`) — all external I/O behind interfaces
   - `interfaces/` — ABCs: `VectorDBInterface`, `EmbeddingInterface`, `LLMInterface`, `ObjectStorageInterface`, `SparseEncoderInterface`, `RerankerInterface`, `TextSplitterInterface`
   - `clients/` — concrete adapters: `QdrantClient`, `OllamaEmbeddingClient` (`embedding_client.py`), `OpenAILLMClient` (`openai_client.py`), `MinIOClient` (`minio_client.py`, uses `aioboto3`), `BGEM3SparseEncoder` (`bge_m3_sparse_client.py`, default), `BM25SparseEncoder` (`bm25_client.py`), `CrossEncoderReranker` (`cross_encoder_client.py`, runs in-process), `LangChainSplitterClient` (`langchain_splitter_client.py`), `MarkdownSplitterClient` (`markdown_splitter_client.py`, for Docling Markdown output)
5. **Workers** (`app/workers/ingestion_worker.py`) — sync functions for PDF parsing and chunking, called via `asyncio.to_thread()`
6. **IoC container** (`app/api/dependencies.py`) — all `@lru_cache` client factories and per-request DB session
7. **Core helpers** (`app/core/helpers.py`) — pure utility functions: `build_material_object_key()` and `build_attachment_object_key()` for constructing MinIO storage paths

### Import paths

`backend/` is the working directory when running the API. All internal imports use the `app.` prefix:
```python
from app.schemas.user_schemas import User        # correct
from schemas.user_schemas import User            # wrong — breaks at runtime
```

### Data models (PostgreSQL tables)

SQLModel schemas in `app/schemas/` define all tables. Each follows the `Base → DB entity (table=True) → Input DTO → Output DTO` pattern. Schema files are domain-split: `user_schemas.py`, `course_schemas.py`, `knowledge_schemas.py` (`Material`), `chat_schemas.py` (`Conversation`, `Message`, `Attachment`, `SharedLink`, `OutputFormat`), `admin_schemas.py` (`SystemPrompt`, `LlmTip`, `TipCategory`); plus non-table helpers `llm_schemas.py` (LLM wire format), `vector_schemas.py` (Qdrant payloads), `time_schema.py` (timestamp mixins).

> **Before editing any schema, read `app/schemas/CLAUDE.md`** — a dependency map listing every file (`scripts/seed.py`, `app/main.py`, routers, services) that must be updated in lockstep when a schema field/table/enum changes. `DATABASE_SCHEMA.md` documents the full table layout.



| Table | SQLModel class | Purpose |
|---|---|---|
| `users` | `User` | Accounts with roles: Student / Professor / Admin |
| `courses` | `Course` | Course containers created by professors |
| `materials` | `Material` | Uploaded files; `vector_namespace` = the Qdrant collection name for that material |
| `conversations` | `Conversation` | Study sessions scoped to a user + optional course |
| `messages` | `Message` | Individual turns; `output_type_requested` drives quiz/info-card/explanation routing |
| `attachments` | `Attachment` | Files attached to a message; stored via `object_storage_key` in MinIO |
| `shared_links` | `SharedLink` | Token-based conversation sharing |
| `system_prompts` | `SystemPrompt` | Course-scoped or global LLM prompts managed by admins |
| `llm_tips` | `LlmTip` | UI tips shown to students |

**Key linkage:** `materials.vector_namespace` is the Qdrant collection name. When a file is ingested, the worker creates/uses a collection with that name and upserts all chunks into it. Currently all files share the single `university_library` collection (see `QDRANT_MATERIALS_COLLECTION` in `config.py`).

**`MessageSender` vs `MessageRole`:** Two separate enums — `chat_schemas.MessageSender` (DB-side: `User`/`System`/`AI`) vs `llm_schemas.MessageRole` (LLM API-side: `system`/`user`/`assistant`). Do not conflate them.

### Dev auth stubs

Auth is not implemented. In `ENVIRONMENT=dev`, `get_current_user` auto-creates a dummy student (`id: 00000000-0000-0000-0000-000000000001`) and `get_dev_course` auto-creates a dev course (`id: 00000000-0000-0000-0000-000000000002`). The course router uses a `HARDCODED_TEACHER_ID`. These stubs raise `501 Not Implemented` in non-dev environments.

### Key design rules (enforced by the team)

**1. 100% async I/O.** Never use `requests`, `time.sleep()`, or synchronous DB drivers. Always `httpx`/`aiohttp`, `asyncio.sleep()`, `asyncpg`. CPU-heavy work (PDF parsing, model inference) goes via `asyncio.to_thread()`.

**2. Dependency Injection via interfaces.** Services must be typed against ABCs (`VectorDBInterface`, not `QdrantClient`). Concrete clients are created once in `dependencies.py` with `@lru_cache()` and injected via `Depends()`. Never instantiate network clients inside routers or services.

**3. Factory pattern for vendor switching.** To add a new provider (e.g. Anthropic instead of OpenAI), implement the interface, add the env var to `config.py`, and switch in the `if/else` block inside `dependencies.py`. Nothing else changes.

**4. LangChain boundary.** LangChain is allowed **only** for prompt templating, LLM abstraction, and output parsers. **Never** use LangChain VectorStores — use native `qdrant-client` SDK inside our `QdrantClient` to keep full metadata filter control.

**5. SQLModel for all relational models.** One class for both the DB table (`table=True`) and API schema. Use Base → DB entity → Input DTO → Output DTO pattern.

**6. Pydantic schemas at API boundaries.** All data crossing the HTTP boundary must go through a model in `app/schemas/`. Never pass raw dicts between layers.

**7. Documentation parity.** When adding a new dependency, env var, or external client, simultaneously update `requirements.txt`, `app/Readme.md`, and `.env.example`.

### Naming conventions

| Thing | Pattern | Example |
|---|---|---|
| Interface ABC | `<Name>Interface` | `VectorDBInterface` |
| Interface file | `<service_name>.py` | `vector_db.py` |
| Concrete client class | `<Name>Client` | `OllamaEmbeddingClient` |
| Client file | `<service_name>_client.py` | `embedding_client.py` |
| Provider selector env var | `<INTERFACE>_CLIENT_TYPE` | `EMBEDDING_CLIENT_TYPE` |
| Service-scoped env vars | `<SERVICE>_*` | `OLLAMA_HOST`, `OLLAMA_EMBED_MODEL` |

### Infrastructure ports
| Service             | Port  | UI                              |
|---------------------|-------|---------------------------------|
| FastAPI             | 8000  | /docs (Swagger)                 |
| Qdrant              | 6333  | http://localhost:6333/dashboard |
| MinIO S3            | 9000  | —                               |
| MinIO UI            | 9001  | http://localhost:9001           |
| PostgreSQL          | 5432  | (use DBeaver/pgAdmin)           |
| Ollama              | 11434 | —                               |
| BGE-M3 / CrossEncoder | —  | in-process (no port); models cached at `~/.cache/huggingface` |
| Next.js dev         | 3000  | http://localhost:3000           |

## Current Implementation Status

**Implemented:**
- `app/main.py` — lifespan creates DB tables, pre-warms BGE-M3 encoder and cross-encoder reranker, connects MinIO
- `app/core/config.py` — all settings classes
- `app/api/dependencies.py` — all `@lru_cache` client factories + DB session + dev auth stubs
- `app/data_access/interfaces/` — 6 ABCs (+ `text_splitter.py`)
- `app/data_access/clients/` — all concrete adapters (Qdrant, Ollama, OpenAI, MinIO, BGE-M3, BM25, CrossEncoder, LangChainSplitter)
- `app/rag_engine/fusion.py` — `rrf_fuse()`: client-side Reciprocal Rank Fusion
- `app/rag_engine/query_rewrite.py` — `build_condensation_messages()`: rewrites follow-up questions into standalone queries
- `app/services/chat_service.py` — full RAG pipeline: hybrid search → RRF → rerank → LLM stream, conversation persistence
- `app/services/file_service.py` — PDF ingestion: parse → chunk → dense+sparse embed → upsert
- `app/services/course_service.py` — CRUD for courses, cascading delete of materials from MinIO and Qdrant
- `app/workers/ingestion_worker.py` — sync PDF extraction (`pypdf`) and chunking (`langchain_text_splitters`)
- `app/api/routers/sessions.py` — chat endpoints (create conversation, list, ask/stream SSE, regenerate SSE, attachment upload/download)
- `app/api/routers/course.py` — course CRUD + materials listing + file upload (`POST /{course_id}/materials`) + material preview (`GET /{course_id}/materials/{material_id}/preview`)
- All `app/schemas/` files

**Note:** There is no `files.py` router. File upload and material management live entirely in `course.py`. Only `sessions` and `course` routers are registered in `main.py`.

**Empty stubs (not yet built):** `admin.py`, `auth.py` routers; `auth_service.py`; `context_builder.py`, `output_formatter.py` RAG modules; `core/security.py`, `core/exceptions.py`.

**Retrieval limit cascade (default `limit=5`):**
- Each search leg fetches `limit * 4 = 20` candidates
- `rrf_fuse()` narrows to `limit * 2 = 10`
- `CrossEncoderReranker.rerank()` returns top `limit = 5` to the LLM

**Migration note:** The `university_library` Qdrant collection must be dropped and recreated after the hybrid-search migration. Named vectors (`"dense"` + `"sparse"`) are required; the old flat-vector schema is incompatible. Re-upload all PDFs after recreating.
