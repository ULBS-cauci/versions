export const config = {
  apiUrl: process.env.NEXT_PUBLIC_API_URL || "http://127.0.0.1:8000",
  apiPrefix: "/api/v1",
} as const;
