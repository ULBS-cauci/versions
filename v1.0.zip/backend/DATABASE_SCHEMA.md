# Database Schema

This document contains the Entity-Relationship mapping for the local PostgreSQL database, generated from the underlying SQLModel implementation.

```mermaid
erDiagram
    %% 0. Lookup / Reference Tables
    output_formats {
        UUID id PK
        string name UK
        string description
        datetime created_at
    }

    tip_categories {
        UUID id PK
        string name UK
        datetime created_at
    }

    %% 1. Identity & Courses
    users {
        UUID id PK
        string email UK
        string first_name
        string last_name
        enum role "Student, Professor, Admin"
        string hashed_password
        datetime created_at
        datetime updated_at
    }

    courses {
        UUID id PK
        string title
        string description
        UUID held_by FK "Ref: users.id"
        datetime created_at
        datetime updated_at
    }

    %% 2. Knowledge Base
    materials {
        UUID id PK
        UUID course_id FK "Ref: courses.id"
        UUID uploaded_by FK "Ref: users.id"
        string file_name
        string file_type
        string vector_namespace
        string object_storage_key
        datetime created_at
    }

    %% 3. Chat System
    conversations {
        UUID id PK
        UUID user_id FK "Ref: users.id"
        UUID course_id FK "Ref: courses.id"
        string title
        datetime created_at
        datetime updated_at
    }

    messages {
        UUID id PK
        UUID conversation_id FK "Ref: conversations.id"
        enum sender "User, System, AI"
        text content
        UUID output_format_id FK "Ref: output_formats.id (nullable)"
        json sources "nullable - array of SourceReference"
        datetime created_at
    }

    attachments {
        UUID id PK
        UUID user_id FK "Ref: users.id"
        UUID message_id FK "Ref: messages.id (nullable)"
        string file_name
        string object_storage_key
        datetime created_at
    }

    shared_links {
        UUID id PK
        UUID conversation_id FK "Ref: conversations.id"
        string token UK
        datetime expires_at
        datetime created_at
    }

    %% 4. Configuration & Prompts
    system_prompts {
        UUID id PK
        UUID author_id FK "Ref: users.id"
        string title
        text content
        datetime created_at
    }

    llm_tips {
        UUID id PK
        UUID category_id FK "Ref: tip_categories.id"
        string title
        text description
        text example_prompt
        datetime created_at
    }

    %% 5. Per-User Settings
    user_settings {
        UUID user_id PK,FK "Ref: users.id (ON DELETE CASCADE)"
        string custom_system_prompt "nullable"
        UUID selected_system_prompt_id FK "Ref: system_prompts.id (nullable)"
        datetime created_at
        datetime updated_at
    }

    %% 6. Learning Paths
    learning_paths {
        UUID id PK
        UUID user_id FK "Ref: users.id"
        UUID course_id FK "Ref: courses.id"
        string title
        string language "dominant language of the materials (nullable)"
        json modules "ordered list of module objects"
        json progress "map module.id -> completed bool"
        datetime created_at
        datetime updated_at
    }

    %% Relationships
    %% Identity & Setup
    users ||--o{ courses : "held_by"
    users ||--o{ materials : "uploaded_by"
    users ||--o{ conversations : "participates_in"
    users ||--o{ system_prompts : "authored_by"
    users ||--o{ attachments : "owns"

    %% Course Data
    courses ||--o{ materials : "contains"
    courses ||--o{ conversations : "context_for"

    %% Chat System
    conversations ||--o{ messages : "contains"
    conversations ||--o| shared_links : "generates"
    messages ||--o{ attachments : "includes"
    messages }o--o| output_formats : "requested_format"

    %% Tips
    tip_categories ||--o{ llm_tips : "categorises"

    %% Per-User Settings (user_id is PK → at most one row per user)
    users ||--o| user_settings : "configures"
    system_prompts ||--o{ user_settings : "selected_in"

    %% Learning Paths
    users ||--o{ learning_paths : "owns"
    courses ||--o{ learning_paths : "covers"
```

## JSON Column: `messages.sources`

The `sources` column stores the RAG retrieval sources used to generate each AI response. It is `NULL` for user and system messages, and populated for AI messages that had matching materials in Qdrant.

Schema of each element in the JSON array:

| Field | Type | Description |
|---|---|---|
| `material_id` | UUID string | FK to `materials.id` |
| `file_name` | string | Display name of the source file |
| `download_url` | string | Relative API path — `/api/v1/courses/{course_id}/materials/{material_id}/download` |

Example value:
```json
[
  {
    "material_id": "9d123bca-...",
    "file_name": "lecture1.pdf",
    "download_url": "/api/v1/courses/c382901a-.../materials/9d123bca-.../download"
  }
]
```

## JSON Columns: `learning_paths.modules` / `learning_paths.progress`

A learning path is a course-wide, ordered curriculum synthesized from all of a course's
materials. `modules` is a JSON array of module objects; `progress` is a JSON object mapping
each module's `id` to a completion flag (validated via `LearningPathModule` on read).

Schema of each `modules` element:

| Field | Type | Description |
|---|---|---|
| `id` | string | Stable module id (e.g. `m1`); also the key used in `progress` |
| `title` | string | Module title |
| `objectives` | string[] | Learning objectives for the module |
| `summary` | string \| null | Short description of what the module covers |
| `material_ids` | UUID string[] | FKs to `materials.id` this module is grounded in |
| `suggested_action` | `"ask_tutor"` \| `"generate_quiz"` \| null | Optional study action |

Example `modules` / `progress`:
```json
// modules
[
  {
    "id": "m1",
    "title": "Foundations",
    "objectives": ["Define core terms"],
    "summary": "Introduces the basic vocabulary.",
    "material_ids": ["9d123bca-..."],
    "suggested_action": "ask_tutor"
  }
]
// progress
{ "m1": true, "m2": false }
```

## Class Diagram

This diagram visualizes the Object-Oriented mapping used by SQLModel (and FastAPI schemas) in the codebase.

```mermaid
classDiagram
    class OutputFormat {
        +UUID id
        +String name
        +String description
        +DateTime created_at
    }

    class TipCategory {
        +UUID id
        +String name
        +DateTime created_at
    }

    class User {
        +UUID id
        +String email
        +String first_name
        +String last_name
        +UserRole role
        +String hashed_password
        +DateTime created_at
        +DateTime updated_at
    }

    class Course {
        +UUID id
        +UUID held_by
        +String title
        +String description
        +DateTime created_at
        +DateTime updated_at
    }

    class Material {
        +UUID id
        +UUID course_id
        +UUID uploaded_by
        +String file_name
        +String file_type
        +String vector_namespace
        +String object_storage_key
        +DateTime created_at
    }

    class Conversation {
        +UUID id
        +UUID user_id
        +UUID course_id
        +String title
        +DateTime created_at
        +DateTime updated_at
    }

    class Message {
        +UUID id
        +UUID conversation_id
        +MessageSender sender
        +Text content
        +UUID output_format_id
        +JSON sources
        +DateTime created_at
    }

    class Attachment {
        +UUID id
        +UUID user_id
        +UUID message_id
        +String file_name
        +String object_storage_key
        +DateTime created_at
    }

    class SharedLink {
        +UUID id
        +UUID conversation_id
        +String token
        +DateTime expires_at
        +DateTime created_at
    }

    class SystemPrompt {
        +UUID id
        +UUID author_id
        +String title
        +Text content
        +DateTime created_at
    }

    class LlmTip {
        +UUID id
        +UUID category_id
        +String title
        +Text description
        +Text example_prompt
        +DateTime created_at
    }

    class UserSetting {
        +UUID user_id
        +String custom_system_prompt
        +UUID selected_system_prompt_id
        +DateTime created_at
        +DateTime updated_at
    }

    class LearningPath {
        +UUID id
        +UUID user_id
        +UUID course_id
        +String title
        +String language
        +JSON modules
        +JSON progress
        +DateTime created_at
        +DateTime updated_at
    }

    %% Relationships as Class Dependencies / Composition
    User "1" --> "*" Course : creates
    User "1" --> "*" SystemPrompt : authors
    User "1" --> "*" Material : uploads
    User "1" --> "*" Conversation : participates
    User "1" --> "*" Attachment : owns

    Course "1" *-- "*" Material : contains
    Course "1" <-- "*" Conversation : references

    Conversation "1" *-- "*" Message : owns
    Conversation "1" *-- "0..1" SharedLink : generates

    Message "1" *-- "*" Attachment : includes
    Message "*" --> "0..1" OutputFormat : requests

    TipCategory "1" *-- "*" LlmTip : categorises

    User "1" --> "0..1" UserSetting : configures
    SystemPrompt "1" <-- "*" UserSetting : selected_by
```

## Object Diagram (Example State)

This diagram shows a sample instantiation of the models at a specific point in time to visualize the relationships in action.

```mermaid
classDiagram
    %% Object Instances
    class professor_john {
        <<User>>
        id: 7f1a3b10...
        first_name: "John"
        role: "Professor"
    }

    class student_jane {
        <<User>>
        id: 4b29c122...
        first_name: "Jane"
        role: "Student"
    }

    class ai_course {
        <<Course>>
        id: c382901a...
        title: "Introduction to AI"
        held_by: 7f1a3b10...
    }

    class lecture_slides {
        <<Material>>
        id: 9d123bca...
        file_name: "lecture1.pdf"
        uploaded_by: 7f1a3b10...
        course_id: c382901a...
    }

    class jane_conversation {
        <<Conversation>>
        id: 11eeb229...
        title: "Doubt regarding Lecture 1"
        user_id: 4b29c122...
        course_id: c382901a...
    }

    class ai_response {
        <<Message>>
        id: 28bc9910...
        conversation_id: 11eeb229...
        sender: "AI"
        content: "Backpropagation is..."
        sources: "[{material_id: 9d123bca...}]"
    }

    class user_attachment {
        <<Attachment>>
        id: 39de18cc...
        user_id: 4b29c122...
        message_id: 28bc9910...
        file_name: "my_notes.docx"
    }

    %% Object Links
    professor_john ..> ai_course : creates
    professor_john ..> lecture_slides : uploads
    ai_course *-- lecture_slides : contains

    student_jane ..> jane_conversation : participates
    jane_conversation ..> ai_course : context

    jane_conversation *-- ai_response : owns
    ai_response *-- user_attachment : contains
```
