from typing import Annotated, Any, List, Literal, Optional, Union
from datetime import datetime, timezone
import uuid
from enum import Enum
from sqlmodel import SQLModel, Field
from sqlalchemy import Column, JSON
from pydantic import BaseModel

from app.schemas.time_schema import TimeSchema, TimestampSchema
from app.schemas.source_schemas import SourceReference, SourcesEvent


class MessageSender(str, Enum):
    USER = "User"
    SYSTEM = "System"
    AI = "AI"


# ==========================================
# OUTPUT FORMAT  (lookup / reference table)
# ==========================================
class OutputFormatBase(SQLModel):
    name: str = Field(unique=True, max_length=100)
    description: Optional[str] = Field(default=None)


class OutputFormat(OutputFormatBase, TimestampSchema, table=True):
    __tablename__ = "output_formats"  # type: ignore
    id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)


class OutputFormatCreate(OutputFormatBase):
    pass


class OutputFormatPublic(OutputFormatBase):
    id: uuid.UUID
    created_at: datetime


# ==========================================
# CHAT CONVERSATION
# ==========================================
class ConversationBase(SQLModel):
    user_id: uuid.UUID = Field(foreign_key="users.id")
    course_id: Optional[uuid.UUID] = Field(default=None, foreign_key="courses.id")
    title: str = Field(default="New Conversation", max_length=255)


class Conversation(ConversationBase, TimeSchema, table=True):
    __tablename__ = "conversations"  # type: ignore
    id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)


class ConversationCreate(ConversationBase):
    pass


class ConversationPublic(ConversationBase):
    id: uuid.UUID
    created_at: datetime
    updated_at: datetime


# ==========================================
# MESSAGE
# ==========================================
class MessageBase(SQLModel):
    conversation_id: uuid.UUID = Field(foreign_key="conversations.id")
    sender: MessageSender
    content: str  # maps to TEXT in PostgreSQL (no max_length)
    output_format_id: Optional[uuid.UUID] = Field(
        default=None, foreign_key="output_formats.id"
    )


class Message(MessageBase, TimestampSchema, table=True):
    __tablename__ = "messages"  # type: ignore
    id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    sources: Optional[list[dict[str, Any]]] = Field(default=None, sa_column=Column(JSON, nullable=True))
    quiz_answers: Optional[list[dict[str, Any]]] = Field(default=None, sa_column=Column(JSON, nullable=True))


class MessageCreate(SQLModel):
    conversation_id: Optional[uuid.UUID] = None
    content: str = Field(default="", description="The content of the message.")
    course_id: Optional[uuid.UUID] = None
    output_format_id: Optional[uuid.UUID] = Field(
        default=None,
        description="Optional FK to output_formats — specifies the desired response format.",
    )
    attachment_ids: List[uuid.UUID] = Field(default_factory=list)
    force_current_course: bool = False
    existing_message_id: Optional[uuid.UUID] = None

# ==========================================
# ATTACHMENT
# ==========================================
class AttachmentBase(SQLModel):
    file_name: str = Field(max_length=255)


class Attachment(AttachmentBase, TimestampSchema, table=True):
    __tablename__ = "attachments"  # type: ignore
    id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    user_id: uuid.UUID = Field(foreign_key="users.id")
    message_id: Optional[uuid.UUID] = Field(default=None, foreign_key="messages.id")
    object_storage_key: str = Field(max_length=2048)


class AttachmentPublic(SQLModel):
    id: uuid.UUID
    file_name: str
    created_at: datetime


class QuizAnswer(BaseModel):
    question: str
    student_answer: str
    correct: bool
    feedback: str


class MessagePublic(MessageBase):
    id: uuid.UUID
    created_at: datetime
    attachments: List[AttachmentPublic] = Field(default_factory=list)
    quiz_answers: Optional[List[QuizAnswer]] = None
    sources: Optional[List[SourceReference]] = None


# ==========================================
# SHARED LINK
# ==========================================
class SharedLinkBase(SQLModel):
    conversation_id: uuid.UUID = Field(foreign_key="conversations.id")
    token: str = Field(unique=True, max_length=64)
    expires_at: Optional[datetime] = Field(default=None)


class SharedLink(SharedLinkBase, TimestampSchema, table=True):
    __tablename__ = "shared_links"  # type: ignore
    id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)


class SharedLinkPublic(SharedLinkBase):
    id: uuid.UUID
    created_at: datetime


class GradeAnswerRequest(BaseModel):
    question: str
    reference_answer: str
    student_answer: str


class GradeAnswerResponse(BaseModel):
    correct: bool
    feedback: str


# Request body for POST /sessions/{message_id}/quiz-answer — same shape as the
# stored QuizAnswer; named separately to keep the API contract explicit.
class QuizAnswerSave(QuizAnswer):
    pass


class StatusEvent(BaseModel):
    type: Literal["status"] = "status"
    message: str


class ChunkEvent(BaseModel):
    type: Literal["chunk"] = "chunk"
    content: str


class ErrorEvent(BaseModel):
    type: Literal["error"] = "error"
    message: str


class ContextSwitchRequestEvent(BaseModel):
    type: Literal["context_switch_request"] = "context_switch_request"
    detected_course_id: str
    detected_course_name: str
    user_message_id: str


class DoneEvent(BaseModel):
    type: Literal["done"] = "done"
    message_id: str


StreamEvent = Annotated[
    Union[StatusEvent, ChunkEvent, ErrorEvent, SourcesEvent, ContextSwitchRequestEvent, DoneEvent],
    Field(discriminator="type"),
]
