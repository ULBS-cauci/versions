import io
import json
import uuid
from pathlib import Path
from typing import List, Optional
from urllib.parse import quote

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlmodel.ext.asyncio.session import AsyncSession

from app.api.dependencies import (
    get_chat_service,
    get_current_user,
    get_db_session,
    get_object_storage_client,
)
from app.core.config import MINIO_ATTACHMENTS_BUCKET
from app.core.helpers import (
    CONTENT_TYPE_BY_EXTENSION,
    build_attachment_object_key,
    content_type_for_filename,
)
from app.data_access.interfaces.object_storage import ObjectStorageInterface
from app.schemas.chat_schemas import (
    Attachment,
    AttachmentPublic,
    ConversationPublic,
    GradeAnswerRequest,
    GradeAnswerResponse,
    MessageCreate,
    MessagePublic,
    OutputFormatPublic,
    QuizAnswerSave,
)
from app.schemas.user_schemas import User
from app.services.chat_service import ChatService


class ConversationCreate(BaseModel):
    course_id: Optional[uuid.UUID] = None

router = APIRouter()

MAX_ATTACHMENT_UPLOAD_BYTES = 10 * 1024 * 1024  # 10 MB


@router.get("/", response_model=List[ConversationPublic])
async def list_conversations(
    current_user: User = Depends(get_current_user),
    service: ChatService = Depends(get_chat_service),
):
    return await service.get_user_conversations(user_id=current_user.id)


@router.post("/", response_model=ConversationPublic)
async def create_conversation(
    body: Optional[ConversationCreate] = None,
    current_user: User = Depends(get_current_user),
    service: ChatService = Depends(get_chat_service),
):
    data = body or ConversationCreate()
    return await service.create_conversation(
        user_id=current_user.id,
        course_id=data.course_id,
    )


@router.post("/grade-answer", response_model=GradeAnswerResponse)
async def grade_answer(
    payload: GradeAnswerRequest,
    service: ChatService = Depends(get_chat_service),
):
    result = await service.grade_free_text_answer(
        payload.question, payload.reference_answer, payload.student_answer
    )
    return GradeAnswerResponse(
        correct=bool(result.get("correct", False)),
        feedback=str(result.get("feedback", "")),
    )


@router.post("/{message_id}/quiz-answer", status_code=status.HTTP_204_NO_CONTENT)
async def save_quiz_answer(
    message_id: uuid.UUID,
    payload: QuizAnswerSave,
    current_user: User = Depends(get_current_user),
    service: ChatService = Depends(get_chat_service),
):
    await service.save_quiz_answer(
        message_id, current_user.id, payload.question, payload.student_answer,
        payload.correct, payload.feedback,
    )


@router.get("/output-formats", response_model=List[OutputFormatPublic])
async def list_output_formats(
    service: ChatService = Depends(get_chat_service),
):
    return await service.list_output_formats()


@router.get("/{conversation_id}/messages", response_model=List[MessagePublic])
async def list_conversation_messages(
    conversation_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    service: ChatService = Depends(get_chat_service),
):
    conversation = await service.get_conversation_for_user(
        conversation_id=conversation_id, user_id=current_user.id
    )
    if not conversation:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Conversation not found")
    return await service.get_conversation_messages_public(conversation_id=conversation_id)


@router.post(
    "/attachments/upload",
    response_model=AttachmentPublic,
    status_code=status.HTTP_201_CREATED,
)
async def upload_attachment(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    object_storage: ObjectStorageInterface = Depends(get_object_storage_client),
    db: AsyncSession = Depends(get_db_session),
):
    filename = file.filename or ""
    suffix = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if not suffix:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=(
                "Cannot determine file type — the file has no extension. "
                f"Accepted: {', '.join(sorted(CONTENT_TYPE_BY_EXTENSION))}"
            ),
        )
    if suffix not in CONTENT_TYPE_BY_EXTENSION:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=(
                f"Unsupported file type '.{suffix}'. "
                f"Accepted: {', '.join(sorted(CONTENT_TYPE_BY_EXTENSION))}"
            ),
        )
    filename = filename or f"attachment.{suffix}"

    # Read up to the size limit + 1 so we can detect oversize uploads without buffering more.
    content = await file.read(MAX_ATTACHMENT_UPLOAD_BYTES + 1)
    if not content:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Uploaded file is empty.",
        )
    if len(content) > MAX_ATTACHMENT_UPLOAD_BYTES:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=(
                f"Uploaded file exceeds the {MAX_ATTACHMENT_UPLOAD_BYTES // (1024 * 1024)} MB limit."
            ),
        )

    attachment_id = uuid.uuid4()
    object_key = build_attachment_object_key(current_user.id, attachment_id, filename)

    await object_storage.upload_file(
        MINIO_ATTACHMENTS_BUCKET, object_key, content, CONTENT_TYPE_BY_EXTENSION[suffix]
    )

    try:
        attachment = Attachment(
            id=attachment_id,
            user_id=current_user.id,
            file_name=filename,
            object_storage_key=object_key,
        )
        db.add(attachment)
        await db.commit()
        await db.refresh(attachment)
    except Exception:
        await object_storage.delete_file(MINIO_ATTACHMENTS_BUCKET, object_key)
        raise

    return AttachmentPublic.model_validate(attachment)


@router.get("/attachments/{attachment_id}")
async def download_attachment(
    attachment_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    object_storage: ObjectStorageInterface = Depends(get_object_storage_client),
    db: AsyncSession = Depends(get_db_session),
):
    attachment = await db.get(Attachment, attachment_id)
    if not attachment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Attachment not found"
        )
    if attachment.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to access this attachment",
        )

    try:
        data = await object_storage.download_file(
            MINIO_ATTACHMENTS_BUCKET, attachment.object_storage_key
        )
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Attachment file is missing from storage",
        )

    encoded_name = quote(attachment.file_name)
    headers = {
        "Content-Disposition": f'inline; filename="{encoded_name}"; filename*=UTF-8\'\'{encoded_name}'
    }
    media_type = content_type_for_filename(attachment.file_name)
    return StreamingResponse(io.BytesIO(data), media_type=media_type, headers=headers)


@router.post("/{conversation_id}/regenerate")
async def regenerate(
    conversation_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    service: ChatService = Depends(get_chat_service),
):
    # Ownership is enforced inside regenerate_stream() (it can't be bypassed by other
    # callers); an unauthorized/unknown conversation surfaces there as an SSE error event.
    async def event_stream():
        try:
            async for chunk in service.regenerate_stream(
                conversation_id=conversation_id, user_id=current_user.id
            ):
                yield f"data: {chunk.model_dump_json()}\n\n"
        except HTTPException as exc:
            yield f"data: {json.dumps({'type': 'error', 'message': exc.detail})}\n\n"
        except Exception:
            yield f"data: {json.dumps({'type': 'error', 'message': 'An unexpected error occurred.'})}\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")


@router.post("/ask")
async def ask(
    payload: MessageCreate,
    current_user: User = Depends(get_current_user),
    service: ChatService = Depends(get_chat_service),
):
    if not payload.content.strip() and not payload.attachment_ids:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Message content or attachment required",
        )

    if payload.conversation_id:
        conversation = await service.get_conversation_for_user(
            conversation_id=payload.conversation_id, user_id=current_user.id
        )
        if not conversation:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Conversation not found or unauthorized",
            )

    async def event_stream():
        try:
            async for event in service.ask_stream(
                query=payload.content,
                user_id=current_user.id,
                conversation_id=payload.conversation_id,
                attachment_ids=payload.attachment_ids,
                output_format_id=payload.output_format_id,
                course_id=payload.course_id,
                force_current_course=payload.force_current_course,
                existing_message_id=payload.existing_message_id,
            ):
                yield f"data: {event.model_dump_json()}\n\n"
        except HTTPException as exc:
            yield f"data: {json.dumps({'type': 'error', 'message': exc.detail})}\n\n"
        except Exception:
            yield f"data: {json.dumps({'type': 'error', 'message': 'An unexpected error occurred.'})}\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")
